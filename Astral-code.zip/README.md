License 🔗

Copyright (c) 2023-2024 Team-Astral (RoboticGermany) ©

The further distribution and use of the files is prohibited without the express permission of Team-Astral (RoboticGermany). 🔐

If copyright is violated, appropriate action will be taken ❗
